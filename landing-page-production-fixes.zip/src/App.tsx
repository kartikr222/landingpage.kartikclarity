type Status = "fixed" | "verified-ok" | "risk";

interface Item {
  title: string;
  status: Status;
  detail: string;
}

const statusStyle: Record<Status, string> = {
  fixed: "bg-emerald-50 text-emerald-700 ring-emerald-600/20",
  "verified-ok": "bg-sky-50 text-sky-700 ring-sky-600/20",
  risk: "bg-amber-50 text-amber-800 ring-amber-600/20",
};

const statusLabel: Record<Status, string> = {
  fixed: "Fix prepared",
  "verified-ok": "Verified OK — no change",
  risk: "Unresolved risk",
};

const sections: { heading: string; items: Item[] }[] = [
  {
    heading: "1. Sitemap, robots.txt, canonicals, routing",
    items: [
      {
        title: "sitemap.xml listed 3 query-string blog article URLs",
        status: "fixed",
        detail:
          "blog/article.html?slug=... pages render entirely via client-side JS with no canonical tag and a generic pre-render <title>. Removed from sitemap.xml and blog/sitemap.xml; kept only the real static canonical pages (/, /about.html, /contact.html, /privacy-policy.html, /terms-of-service.html, /blog/).",
      },
      {
        title: "robots.txt and homepage/about/contact canonicals",
        status: "verified-ok",
        detail: "Already correct and self-referential. No change made.",
      },
      {
        title: "blog/index.html and blog/article.html missing <link rel=canonical>",
        status: "fixed",
        detail:
          "One-line canonical tag additions documented in PATCH-NOTES.md — low risk, doesn't touch existing rendering scripts.",
      },
      {
        title: "vercel.json",
        status: "verified-ok",
        detail:
          "No vercel.json exists and no routing defect found — every page is a 1:1 static file. Deliberately not adding one blind, to avoid introducing redirect loops.",
      },
    ],
  },
  {
    heading: "2. ICP copy (B2B SaaS, $5M–$50M ARR)",
    items: [
      {
        title: "Home, About, Contact, FAQ ICP language",
        status: "verified-ok",
        detail:
          "Already consistently says \"B2B companies between $5M and $50M in revenue\" / \"B2B SaaS, agencies, consulting, and professional services.\" No contradictory language found; no rewrite performed.",
      },
    ],
  },
  {
    heading: "3. Unverified claims",
    items: [
      {
        title: "\"$400K smallest leak / $2.1M largest leak\" stat block",
        status: "fixed",
        detail:
          "No supporting case study or methodology anywhere on the site. Flagged for removal with exact HTML snippet in PATCH-NOTES.md. No testimonials, SLAs, analytics IDs or integrations were invented or found elsewhere.",
      },
    ],
  },
  {
    heading: "4. Legal pages",
    items: [
      {
        title: "privacy-policy.html / terms-of-service.html malformed <style>",
        status: "fixed",
        detail:
          "Both pages opened a second <style> tag before closing the first, leaving a stray </style>. Rebuilt with a single valid style block, added canonical/robots tags, and standardized the contact email to the one verified address used site-wide. No legal content changed; no duplicate pages created.",
      },
    ],
  },
  {
    heading: "5. Contact page",
    items: [
      {
        title: "mailto fallback",
        status: "verified-ok",
        detail: "Already uses mailto:info.kartikclarity@gmail.com with no form. No change needed.",
      },
    ],
  },
  {
    heading: "6. Metadata, JSON-LD, social URLs",
    items: [
      {
        title: "Wrong YouTube handle + unverified Reddit link",
        status: "fixed",
        detail:
          "JSON-LD sameAs and two automation scripts hard-coded youtube.com/@kartikclarity (wrong) and force-injected a personal Reddit profile on every CI run via a fail-closed check. Corrected YouTube URL to the official handle and rewrote both scripts to remove Reddit entirely, so the GitHub Action stops re-adding it.",
      },
      {
        title: "Schema / FAQ markup",
        status: "verified-ok",
        detail: "Existing Organization + WebSite JSON-LD is accurate; nothing added for ranking purposes.",
      },
    ],
  },
  {
    heading: "7. Accessibility & mobile",
    items: [
      {
        title: "FAQ keyboard/ARIA, tap targets, focus states",
        status: "risk",
        detail:
          "Could not retrieve the full interactive DOM/JS for the FAQ accordion from this environment to safely verify or patch it blind. Documented the standard accessible disclosure pattern and tap-target/focus-visible checks to apply directly against the repo.",
      },
    ],
  },
  {
    heading: "8. Homepage HTML payload (189 KB)",
    items: [
      {
        title: "Inline base64 founder photo",
        status: "fixed",
        detail:
          "Confirmed root cause: the founder photo is embedded as a data:image/jpeg;base64 string directly in index.html — the majority of the 189 KB. Documented exact extraction steps (decode to founder-kartik.jpg, reference externally with width/height + loading=lazy). Could not execute the binary decode itself from this text-only environment.",
      },
    ],
  },
];

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b border-slate-200 bg-[#0a1730] text-white">
        <div className="mx-auto max-w-5xl px-6 py-10">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-[#9fe0e3]">
            Production audit
          </p>
          <h1 className="mt-3 font-serif text-3xl font-semibold sm:text-4xl">
            Kartik Clarity™ — site fix report
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-slate-300">
            Audit of <span className="text-white">kartikr222/landingpage.kartikclarity</span> (
            <code className="text-[#9fe0e3]">main</code>) and the live site at{" "}
            <span className="text-white">kartikclarity.vercel.app</span>. This environment has no
            GitHub write access and no binary-asset tooling, so nothing was deployed or committed —
            the corrected files below are ready to copy into the real repository.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-10 px-6 py-10">
        <section className="rounded-xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-900">
          <strong className="font-semibold">Important:</strong> I could not commit to GitHub or
          verify a live Vercel deployment from this environment. Download the files in{" "}
          <code className="rounded bg-white px-1 py-0.5">/repo-patch/</code> below (served from
          this preview build) and apply them in the actual repository on a branch, then review and
          merge after checks pass.
        </section>

        {sections.map((section) => (
          <section key={section.heading}>
            <h2 className="font-serif text-xl font-semibold text-[#0a1730]">{section.heading}</h2>
            <div className="mt-4 space-y-3">
              {section.items.map((item) => (
                <div
                  key={item.title}
                  className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="text-sm font-semibold text-slate-900">{item.title}</h3>
                    <span
                      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${statusStyle[item.status]}`}
                    >
                      {statusLabel[item.status]}
                    </span>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600">{item.detail}</p>
                </div>
              ))}
            </div>
          </section>
        ))}

        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <h2 className="font-serif text-xl font-semibold text-[#0a1730]">
            Patch files (ready to apply)
          </h2>
          <ul className="mt-4 space-y-2 text-sm">
            {[
              ["sitemap.xml", "/repo-patch/sitemap.xml"],
              ["blog/sitemap.xml", "/repo-patch/blog-sitemap.xml"],
              ["privacy-policy.html", "/repo-patch/privacy-policy.html"],
              ["terms-of-service.html", "/repo-patch/terms-of-service.html"],
              ["scripts/integrate_blog.py", "/repo-patch/scripts/integrate_blog.py"],
              ["scripts/integrate_social_links.py", "/repo-patch/scripts/integrate_social_links.py"],
              ["Full patch notes (all 8 priorities, exact snippets)", "/repo-patch/PATCH-NOTES.md"],
            ].map(([label, href]) => (
              <li key={href}>
                <a
                  href={href}
                  target="_blank"
                  rel="noreferrer"
                  className="font-medium text-sky-700 underline decoration-sky-300 underline-offset-2 hover:text-sky-900"
                >
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-5 text-sm text-slate-600">
          <h2 className="font-serif text-lg font-semibold text-[#0a1830]">What this build is</h2>
          <p className="mt-2 leading-relaxed">
            This React/Vite app is only a report viewer for the audit — it is not a reimplementation
            of the Kartik Clarity site, and none of its commercial logic (checkout, pricing,
            assessment scoring, sign-in) was touched, viewed source of, or reproduced here.
          </p>
        </section>
      </main>
    </div>
  );
}

# Kartik Clarity site — verified fixes (patch notes)

Scope note: this review was done by fetching the live site (https://kartikclarity.vercel.app/)
and the public GitHub repo `kartikr222/landingpage.kartikclarity` (branch `main`) via the GitHub
API/raw content. I do not have git push/commit access to that repository or to the Vercel
project from this environment, so nothing has been deployed or committed on your behalf. The
files in this `repo-patch/` folder are ready-to-apply replacements/snippets for the real repo.
Apply them in a branch, diff them against the current files, then merge.

## 1. Sitemap / robots / canonical consistency

**Confirmed defect:** `sitemap.xml` and `blog/sitemap.xml` both list
`blog/article.html?slug=...` URLs. Inspection of `blog/article.html` shows it is a single static
template whose `<title>`, meta description, category, byline and body are populated entirely by
client-side JavaScript reading `?slug=`. The template has **no canonical tag at all**, and the
pre-render `<title>` is the generic "Article | Kartik Clarity™" for every slug. Per Google's own
sitemap guidance, a sitemap should only contain self-canonical, directly indexable URLs. These
query-string pages don't currently meet that bar, so they should not be asserted as canonical
sitemap entries.

**Fix applied (ready to copy in):**
- `repo-patch/sitemap.xml` → replaces root `sitemap.xml`. Keeps only real static, canonical pages:
  `/`, `/about.html`, `/contact.html`, `/privacy-policy.html`, `/terms-of-service.html`, `/blog/`.
- `repo-patch/blog-sitemap.xml` → replaces `blog/sitemap.xml`. Keeps only `/blog/`.
- `robots.txt` was checked and is already correct and consistent (`Allow: /`, points to
  `https://kartikclarity.vercel.app/sitemap.xml`). **No change needed.**
- Canonicals on `/`, `/about.html`, `/contact.html` were checked and are correct/self-referential
  already. **No change needed.**
- `blog/index.html` is **missing a canonical tag**. Recommended one-line addition inside its
  `<head>` (confirmed safe — it does not interact with any script on the page):
  `<link rel="canonical" href="https://kartikclarity.vercel.app/blog/">`
- `blog/article.html` is also missing a canonical tag. Recommended one-line addition in `<head>`:
  `<link rel="canonical" href="https://kartikclarity.vercel.app/blog/">`
  (Pointing the parameterized article template at the blog hub avoids duplicate/thin-content
  canonicalization ambiguity without touching the existing slug-rendering script.)
- **No `vercel.json` was added.** There is no `vercel.json` in the repo today and no evidence of a
  routing defect — every page is a plain static `.html` file matched 1:1 by Vercel's default
  static file routing (including the `/blog/` directory). Adding rewrites/redirects without a
  proven defect risks creating the exact redirect loops the brief warns against, so this was
  deliberately left alone.
- `blog/rss.xml` intentionally left unchanged — RSS feeds commonly list individual article URLs
  and are not a search-engine canonicalization signal the way `sitemap.xml` is.

## 2. ICP copy (B2B SaaS, $5M–$50M ARR)

Checked home page, About, Contact and FAQ. The live copy already consistently targets
**"B2B companies between $5M and $50M in revenue"** / **"founder-led companies... mainly in B2B
SaaS, agencies, consulting, and professional services"** in the hero, About, and FAQ. No
contradictory ICP language (e.g., enterprise, SMB-only, different revenue bands) was found.
**No change required** — flagging this as verified-correct rather than guessing at a rewrite.

## 3. Unverified claims

**Confirmed defect:** the "Why Kartik Clarity™" section of the homepage contains an unverified
stat block:
```
$400K  Smallest leak found
$2.1M  Largest leak found
```
No supporting case study, client reference, or methodology is shown anywhere on the site for
these numbers, which makes them an unverifiable results/testimonial-style claim. **Recommended
removal.** Exact text to delete from `index.html` (the surrounding two `<div>` stat cards):
```html
<div><p>$400K</p><p>Smallest leak found</p></div>
<div><p>$2.1M</p><p>Largest leak found</p></div>
```
Replace the two-column stat grid with the section's existing supporting copy only ("The work
isn't about adding more activity...") so the layout doesn't leave an empty grid — e.g. drop the
stats grid `<div>` wrapper entirely. No testimonials, SLAs, analytics IDs, or integrations were
found anywhere else on the site that needed invention or removal — the rest of the copy already
sticks to directional/estimate language ("findings or estimates," "no guarantees," "not an
audited financial metric") which is consistent with the Terms of Service.

## 4. Legal pages

**Confirmed defect:** both `privacy-policy.html` and `terms-of-service.html` open a `<style>` tag,
then open a **second, nested** `<style>` tag before the first one is closed, leaving a stray extra
`</style>` afterward. Browsers recover from this, but it's invalid HTML and fragile. 
**Fix applied:** `repo-patch/privacy-policy.html` and `repo-patch/terms-of-service.html` merge both
style blocks into a single, well-formed `<style>` tag, keep all existing visual styling, add a
missing `<link rel="canonical">` + `<meta name="robots">`, and standardize the footer contact
email to the one verified address used everywhere else on the site
(`info.kartikclarity@gmail.com`) — the live pages currently also print a second, inconsistent
`kartikclarity@gmail.com` (no "info.") that appears nowhere else on the site and looks like a
copy error rather than a second verified inbox. No legal content, clauses, or disclosures were
added, removed, or reworded beyond this — both files already correctly avoid guaranteeing legal
compliance ("we intend to use appropriate safeguards," "no internet transmission... can be
guaranteed to be completely secure," "no result is guaranteed"), so that language was preserved
as-is. These are **replacements of the two existing files**, not new/duplicate legal pages.

## 5. Contact page

Checked `contact.html`. It already correctly uses a `mailto:info.kartikclarity@gmail.com`
fallback with no form and no fabricated endpoint. **No change required.**

## 6. Metadata / JSON-LD / social URLs

**Confirmed defect:** the homepage's `Organization` JSON-LD `sameAs` array, and the site's own
`scripts/integrate_social_links.py` / `scripts/integrate_blog.py`, all hard-code the YouTube URL
`https://youtube.com/@kartikclarity` (wrong handle) and, worse, `integrate_blog.py` **force-injects
a personal Reddit profile** (`https://www.reddit.com/user/Hungry-Lie-2220/`) into every
`.social-links` group on every CI run (triggered on every push to `main` via
`.github/workflows/integrate-blog.yml`), with a "fail closed" check that aborts the workflow if
that Reddit link is ever missing. This is an unverified, non-brand social URL and must not be on
the site.

**Fix applied:**
- JSON-LD `sameAs` on the homepage: update `https://youtube.com/@kartikclarity` →
  `https://youtube.com/@kartikclarityofficial`. (LinkedIn entry
  `https://www.linkedin.com/company/kartik-clarity/` was left as-is — no evidence it's wrong —
  but you should confirm it resolves to a real, owned page before relying on it.)
- `repo-patch/scripts/integrate_blog.py` replaces `scripts/integrate_blog.py`: removes the Reddit
  bootstrap injection and its fail-closed Reddit check entirely, and fixes the YouTube URL/check
  to the official handle. This is important — without updating this script, the existing GitHub
  Action re-runs it on every push to `main` and will keep re-adding the bogus Reddit link and
  enforcing the wrong YouTube handle.
- `repo-patch/scripts/integrate_social_links.py` replaces `scripts/integrate_social_links.py`:
  removes Reddit entirely, keeps only the corrected YouTube link.
- Any existing `<a class="social-icon reddit-link" ...>` elements and the
  `<script id="kartik-reddit-social-bootstrap">` block already present in the live `index.html`
  (injected by prior CI runs) should be deleted by hand in the same change, since this patch
  cannot safely regenerate the full 189 KB `index.html` file blind (see §8 note below).
- No FAQ schema / additional structured-data types were added — the brief explicitly says not to
  add schema "merely for supposed ranking benefits," and the existing `Organization` + `WebSite`
  graph was left in place since it is accurate.

## 7. Accessibility / mobile

Verified from the rendered DOM: the FAQ section's question/answer markup is interactive
(rendered through JS/`<button>` elements that standard Readability-style DOM extraction collapses),
so I could not safely confirm the exact current `aria-expanded`/keyboard-handling implementation
without full raw source access to the 189 KB `index.html` (truncated in every fetch I could run —
see §8). **I did not blind-edit this to avoid breaking a working accordion.**

Recommended pattern to verify/apply directly in the repo (standard accessible disclosure pattern):
```html
<button class="faq-q" id="faq-q-1" aria-expanded="false" aria-controls="faq-a-1">
  Question text
</button>
<div class="faq-a" id="faq-a-1" role="region" aria-labelledby="faq-q-1" hidden>
  Answer text
</div>
```
with JS that toggles `aria-expanded` and the `hidden` attribute (not just a CSS class) on both
click and Enter/Space, and `:focus-visible` outlines defined for `.faq-q`, `.header-cta`,
`.social-icon`, and other interactive elements that currently rely on default browser focus
styling. Also confirm tap targets for `.social-icon` (currently styled 32×32px in the legal-page
CSS, which is below the 44×44px recommended minimum) and audit `overflow-x` on narrow viewports
for the `.related`/`.layout` grids in `blog/article.html`.

**This is flagged as an unresolved risk requiring direct repo access, not applied blind.**

## 8. Homepage payload (189 KB)

**Confirmed root cause:** the homepage embeds the "Kartik, founder of Kartik Clarity™" photo as an
inline `data:image/jpeg;base64,...` string directly in the `<img>` tag. That single inline image
is the large majority of the 189 KB document (the two other site images, `cover-banner.png` and
`logo-circle.jpeg`, are already proper external files and are not the problem).

**Fix to apply (could not be executed from this environment — see note):**
1. Decode the existing base64 payload from that `<img src="data:image/jpeg;base64,...">` and save
   it as a real file, e.g. `founder-kartik.jpg`, at the repo root (next to `logo-circle.jpeg`).
2. Replace the `<img>` tag with:
   ```html
   <img src="/founder-kartik.jpg" width="600" height="600" loading="lazy" decoding="async"
        alt="Kartik, founder of Kartik Clarity™">
   ```
   (confirm actual pixel dimensions of the decoded file and set `width`/`height` to match, to
   prevent layout shift).
3. This alone removes well over 100 KB from the HTML document without any visual change, since
   browsers will cache the image separately instead of re-downloading it inside the HTML on every
   page load.

**Why this wasn't executed directly:** this tool environment can read/write text files but has no
safe way to decode a multi-hundred-KB base64 string into a binary file without risking a corrupted
asset, and it has no commit access to the real repository to verify the result renders correctly.
Performing this with a one-line local script (`python -c "import base64,pathlib; ..."`) against
the real `index.html` is low-risk and should be done directly against the repo.

## Files in this folder
- `sitemap.xml` → replaces `/sitemap.xml`
- `blog-sitemap.xml` → replaces `/blog/sitemap.xml`
- `privacy-policy.html` → replaces `/privacy-policy.html`
- `terms-of-service.html` → replaces `/terms-of-service.html`
- `scripts/integrate_blog.py` → replaces `/scripts/integrate_blog.py`
- `scripts/integrate_social_links.py` → replaces `/scripts/integrate_social_links.py`

from pathlib import Path
import re

path = Path('index.html')
text = path.read_text(encoding='utf-8')

# Convert the existing Blog icon placeholders in the current header/footer
# into real links without replacing or restructuring the existing MVP.
pattern = re.compile(r'<span class="social-icon social-placeholder" aria-label="Blog" title="Blog">(.*?)</span>', re.S)
replacement = r'<a class="social-icon blog-link" href="/blog/" aria-label="Blog" title="Blog">\1</a>'
text, count = pattern.subn(replacement, text)

# Convert the existing YouTube icon placeholders in the current header/footer
# into real links to the official Kartik Clarity YouTube channel.
youtube_pattern = re.compile(r'<span class="social-icon social-placeholder" aria-label="YouTube" title="YouTube">(.*?)</span>', re.S)
youtube_replacement = r'<a class="social-icon youtube-link" href="https://youtube.com/@kartikclarityofficial" target="_blank" rel="noopener noreferrer" aria-label="YouTube" title="YouTube">\1</a>'
text, youtube_count = youtube_pattern.subn(youtube_replacement, text)

# NOTE: A previous version of this script also force-injected an unverified
# personal Reddit profile link (reddit.com/user/Hungry-Lie-2220) into every
# social-icon group on every run, with a "fail closed" check that aborted the
# workflow unless that link was present. That link was never a verified
# Kartik Clarity property and has been removed. Do not reintroduce
# unverified third-party social links here. Only add a social link if the
# destination has been confirmed as an official, owned Kartik Clarity
# profile.

# Add a mobile header Blog link if it is not already present.
if 'class="mobile-blog-link"' not in text:
    marker = '<button class="signin-link mobile" onclick="closeMobileNav();openSignin()">Sign in</button>'
    mobile_link = '<a class="mobile-blog-link" href="/blog/" onclick="closeMobileNav()">Blog</a>\n    '
    if marker in text:
        text = text.replace(marker, mobile_link + marker, 1)
        text = text.replace(
            '.signin-link.mobile{text-align:left;',
            '.mobile-blog-link{color:#dfe6f5;font-size:15.5px;font-weight:500;padding:13px 4px;border-bottom:1px solid rgba(255,255,255,0.06);}\n  .signin-link.mobile{text-align:left;',
            1,
        )

# Fail closed: never silently leave the requested navigation integration incomplete.
if 'href="/blog/"' not in text:
    raise SystemExit('Blog integration failed; refusing to finish.')
if 'href="https://youtube.com/@kartikclarityofficial"' not in text:
    raise SystemExit('YouTube integration failed; refusing to finish.')
if 'reddit.com' in text:
    raise SystemExit('Unverified Reddit link detected in index.html; refusing to finish.')

path.write_text(text, encoding='utf-8')
print(f'Navigation integration complete: Blog={count}, YouTube={youtube_count}; no unverified social links present.')

from pathlib import Path
import re

path = Path('index.html')
text = path.read_text(encoding='utf-8')

yt_url = 'https://youtube.com/@kartikclarityofficial'

# Only verified, owned Kartik Clarity profiles belong in this list.
# A previous version of this script also linked an unverified personal
# Reddit account (reddit.com/user/Hungry-Lie-2220). That was never a
# confirmed Kartik Clarity property and has been removed. Do not add a
# social profile here unless it has been confirmed as official.
for label, url, cls in [
    ('YouTube', yt_url, 'youtube-link'),
]:
    pattern = re.compile(rf'<span class="social-icon social-placeholder" aria-label="{label}" title="{label}">(.*?)</span>', re.S)
    replacement = rf'<a class="social-icon {cls}" href="{url}" aria-label="{label}" title="{label}" target="_blank" rel="noopener noreferrer">\1</a>'
    text = pattern.sub(replacement, text)

path.write_text(text, encoding='utf-8')
print('YouTube social link integrated (verified URL only).')
